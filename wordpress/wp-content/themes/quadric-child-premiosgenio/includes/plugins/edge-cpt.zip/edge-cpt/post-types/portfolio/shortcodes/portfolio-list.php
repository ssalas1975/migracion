<?php
namespace EdgeCore\CPT\Portfolio\Shortcodes;

use EdgeCore\Lib;

/**
 * Class PortfolioList
 * @package EdgeCore\CPT\Portfolio\Shortcodes
 */
class PortfolioList implements Lib\ShortcodeInterface
{
	/**
	 * @var string
	 */
	private $base;

	public function __construct()
	{
		$this->base = 'edgtf_portfolio_list';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase()
	{
		return $this->base;
	}

	/**
	 * Maps shortcode to Visual Composer
	 *
	 * @see vc_map
	 */
	public function vcMap()
	{
		if (function_exists('vc_map')) {

			$icons_array = array();
			if (edgtf_core_theme_installed()) {
				$icons_array = \EdgeQuadricIconCollections::get_instance()->getVCParamsArray();
			}

			vc_map(array(
					'name' => 'Portfolio List',
					'base' => $this->getBase(),
					'category' => 'by EDGE',
					'icon' => 'icon-wpb-portfolio extended-custom-icon',
					'allowed_container_element' => 'vc_row',
					'params' => array(
						array(
							'type' => 'dropdown',
							'heading' => 'Portfolio List Template',
							'param_name' => 'type',
							'value' => array(
								'Standard' => 'standard',
								'Gallery' => 'gallery',
								'Gallery With Space' => 'gallery_with_space',
								'Masonry' => 'masonry',
								'Masonry With Space' => 'masonry_with_space',
							),
							'admin_label' => true,
							'description' => ''
						),
						array(
							'type' => 'dropdown',
							'heading' => 'Title Tag',
							'param_name' => 'title_tag',
							'value' => array(
								'' => '',
								'h2' => 'h2',
								'h3' => 'h3',
								'h4' => 'h4',
								'h5' => 'h5',
								'h6' => 'h6',
							),
							'admin_label' => true,
							'description' => ''
						),
						array(
							'type' => 'dropdown',
							'heading' => 'Image Proportions',
							'param_name' => 'image_size',
							'value' => array(
								'Original' => 'full',
								'Square' => 'square',
								'Landscape' => 'landscape',
								'Portrait' => 'portrait'
							),
							'save_always' => true,
							'admin_label' => true,
							'description' => '',
							'dependency' => array('element' => 'type', 'value' => array('standard', 'gallery', 'gallery_with_space'))
						),
						array(
							'type' => 'dropdown',
							'heading' => 'Show Load More',
							'param_name' => 'show_load_more',
							'value' => array(
								'Yes' => 'yes',
								'No' => 'no'
							),
							'save_always' => true,
							'admin_label' => true,
							'description' => 'Default value is Yes'
						),
						array(
							'type' => 'dropdown',
							'heading' => 'Animation',
							'param_name' => 'animation',
							'value' => array(
								'Upward' => 'edgtf-upward-hover-animation',
								'Slide Up' => 'edgtf-slide-up-hover-animation',
								'Push' => 'edgtf-push-hover-animation',
								'Shift' => 'edgtf-shift-hover-animation',
								'Image Zooming' => 'edgtf-image-zoom-animation',
							),
							'save_always' => true,
							'dependency' => array('element' => 'type', 'value' => array('gallery', 'gallery_with_space', 'masonry', 'masonry_with_space'))
						),
						array(
							'type' => 'dropdown',
							'heading' => 'Order By',
							'param_name' => 'order_by',
							'value' => array(
								'Date' => 'date',
								'Menu Order' => 'menu_order',
								'Title' => 'title',
							),
							'admin_label' => true,
							'save_always' => true,
							'description' => '',
							'group' => 'Query and Layout Options'
						),
						array(
							'type' => 'dropdown',
							'heading' => 'Order',
							'param_name' => 'order',
							'value' => array(
								'ASC' => 'ASC',
								'DESC' => 'DESC',
							),
							'admin_label' => true,
							'save_always' => true,
							'description' => '',
							'group' => 'Query and Layout Options'
						),
						array(
							'type' => 'textfield',
							'heading' => 'One-Category Portfolio List',
							'param_name' => 'category',
							'value' => '',
							'admin_label' => true,
							'description' => 'Enter one category slug (leave empty for showing all categories)',
							'group' => 'Query and Layout Options'
						),
						array(
							'type' => 'textfield',
							'heading' => 'Number of Portfolios Per Page',
							'param_name' => 'number',
							'value' => '-1',
							'admin_label' => true,
							'description' => '(enter -1 to show all)',
							'group' => 'Query and Layout Options'
						),
						array(
							'type' => 'dropdown',
							'heading' => 'Number of Columns',
							'param_name' => 'columns',
							'value' => array(
								'' => '',
								'One' => 'one',
								'Two' => 'two',
								'Three' => 'three',
								'Four' => 'four',
								'Five' => 'five',
								'Six' => 'six'
							),
							'admin_label' => true,
							'description' => 'Default value is Three',
							'group' => 'Query and Layout Options'
						),
						array(
							'type' => 'textfield',
							'heading' => 'Show Only Projects with Listed IDs',
							'param_name' => 'selected_projects',
							'value' => '',
							'admin_label' => true,
							'description' => 'Delimit ID numbers by comma (leave empty for all)',
							'group' => 'Query and Layout Options'
						),
						array(
							'type' => 'dropdown',
							'heading' => 'Enable Category Filter',
							'param_name' => 'filter',
							'value' => array(
								'No' => 'no',
								'Yes' => 'yes'
							),
							'admin_label' => true,
							'save_always' => true,
							'description' => 'Default value is No',
							'group' => 'Query and Layout Options'
						),
						array(
							'type' => 'dropdown',
							'heading' => 'Filter Order By',
							'param_name' => 'filter_order_by',
							'value' => array(
								'Name' => 'name',
								'Count' => 'count',
								'Id' => 'id',
								'Slug' => 'slug'
							),
							'admin_label' => true,
							'save_always' => true,
							'description' => 'Default value is Name',
							'dependency' => array('element' => 'filter', 'value' => array('yes')),
							'group' => 'Query and Layout Options'
						)
					)
				)
			);
		}
	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 * @return string
	 */
	public function render($atts, $content = null)
	{

		$args = array(
			'type' => 'standard',
			'columns' => 'three',
			'grid_size' => 'three',
			'image_size' => 'full',
			'order_by' => 'date',
			'order' => 'ASC',
			'number' => '-1',
			'filter' => 'no',
			'filter_order_by' => 'name',
			'category' => '',
			'selected_projects' => '',
			'show_load_more' => 'yes',
			'title_tag' => 'h5',
			'next_page' => '',
			'portfolio_slider' => '',
			'next_page' => '',
			'portfolios_shown' => '',
			'animation' => ''
		);

		$params = shortcode_atts($args, $atts);
		extract($params);

		$query_array = $this->getQueryArray($params);
		$query_results = new \WP_Query($query_array);
		$params['query_results'] = $query_results;

		$classes = $this->getPortfolioClasses($params);
		$data_atts = $this->getDataAtts($params);
		$data_atts .= 'data-max-num-pages = ' . $query_results->max_num_pages;
		$params['masonry_filter'] = '';

		$html = '';
		if ($filter == 'yes' && ($type == 'masonry' || $type == 'masonry_with_space')) {
			$params['filter_categories'] = $this->getFilterCategories($params);
			$params['masonry_filter'] = 'edgtf-masonry-filter';
			$html .= edgtf_core_get_shortcode_module_template_part('portfolio', 'portfolio-filter', '', $params);
		}

		$html .= '<div class = "edgtf-portfolio-list-holder-outer ' . $classes . '" ' . $data_atts . '>';

		if ($filter == 'yes' && ($type == 'standard' || $type == 'gallery' || $type == 'gallery_with_space')) {
			$params['filter_categories'] = $this->getFilterCategories($params);
			$html .= edgtf_core_get_shortcode_module_template_part('portfolio', 'portfolio-filter', '', $params);
		}

		$html .= '<div class = "edgtf-portfolio-list-holder clearfix ' . $animation . '" >';
		if ($type == 'masonry' || $type == 'masonry_with_space') {
			$html .= '<div class="edgtf-portfolio-list-masonry-grid-sizer"></div>';
			$html .= '<div class="edgtf-portfolio-list-masonry-grid-gutter"></div>';
		}

		if ($query_results->have_posts()) {
			while ($query_results->have_posts()) {
				$query_results->the_post();

				$params['current_id'] = get_the_ID();
				$params['thumb_size'] = $this->getImageSize($params);
				$params['icon_html'] = $this->getPortfolioIconsHtml($params);
				$params['category_html'] = $this->getItemCategoriesHtml($params);
				$params['categories'] = $this->getItemCategories($params);
				$params['article_masonry_size'] = $this->getMasonrySize($params);
				$params['item_link'] = $this->getItemLink($params);
				$html .= edgtf_core_get_shortcode_module_template_part('portfolio', $type, '', $params);
			}
			if (empty($params['portfolio_slider']) && ($params['type'] == 'gallery_with_space' || $params['type'] == 'standard')) {
				$map = array(
					'one' => '1',
					'two' => '2',
					'three' => '3',
					'four' => '4',
					'five' => '5',
					'six' => '6'
				);
				for ($i = 0; $i < $map[$params['columns']]; $i++) {
					$html .= '<div class="edgtf-ptf-gap"></div>';
				}
			}
		} else {

			$html .= '<p>' . _e('Sorry, no posts matched your criteria.') . '</p>';

		}
		$html .= '</div>'; //close edgtf-portfolio-list-holder		
		wp_reset_postdata();
		if ($show_load_more == 'yes' && empty($params['portfolio_slider'])) {
			$html .= edgtf_core_get_shortcode_module_template_part('portfolio', 'load-more-template', '', $params);
		}
		$html .= '</div>'; // close edgtf-portfolio-list-holder-outer		
		return $html;
	}

	/**
	 * Generates portfolio list query attribute array
	 *
	 * @param $params
	 *
	 * @return array
	 */
	public function getQueryArray($params)
	{

		$query_array = array();

		$query_array = array(
			'post_type' => 'portfolio-item',
			'orderby' => $params['order_by'],
			'order' => $params['order'],
			'posts_per_page' => $params['number']
		);

		if (!empty($params['category'])) {
			$query_array['portfolio-category'] = $params['category'];
		}

		$project_ids = null;
		if (!empty($params['selected_projects'])) {
			$project_ids = explode(',', $params['selected_projects']);
			$query_array['post__in'] = $project_ids;
		}

		$paged = '';
		if (empty($params['next_page'])) {
			if (get_query_var('paged')) {
				$paged = get_query_var('paged');
			} elseif (get_query_var('page')) {
				$paged = get_query_var('page');
			}
		}

		if (!empty($params['next_page'])) {
			$query_array['paged'] = $params['next_page'];

		} else {
			$query_array['paged'] = 1;
		}

		return $query_array;
	}

	/**
	 * Generates portfolio icons html
	 *
	 * @param $params
	 *
	 * @return html
	 */
	public function getPortfolioIconsHtml($params)
	{

		$html = '';
		$id = $params['current_id'];
		$slug_list_ = 'pretty_photo_gallery';

		$featured_image_array = wp_get_attachment_image_src(get_post_thumbnail_id($id), 'full'); //original size				
		$large_image = $featured_image_array[0];

		$html .= '<div class="edgtf-item-icons-holder">';

		$html .= '<a class="edgtf-portfolio-lightbox" title="' . get_the_title($id) . '" href="' . $large_image . '" data-rel="prettyPhoto[' . $slug_list_ . ']" rel="prettyPhoto[' . $slug_list_ . ']"></a>';


		if (function_exists('edgtf_quadric_like_portfolio_list')) {
			$html .= edgtf_quadric_like_portfolio_list($id);
		}

		$html .= '<a class="edgtf-preview" title="Go to Project" href="' . $this->getItemLink($params) . '" data-type="portfolio_list"></a>';

		$html .= '</div>';

		return $html;

	}

	/**
	 * Generates portfolio classes
	 *
	 * @param $params
	 *
	 * @return string
	 */
	public function getPortfolioClasses($params)
	{
		$classes = array();
		$type = $params['type'];
		$columns = $params['columns'];
		$grid_size = $params['grid_size'];
		switch ($type):
			case 'standard':
				$classes[] = 'edgtf-ptf-standard';
				break;
			case 'gallery':
				$classes[] = 'edgtf-ptf-gallery';
				break;
			case 'gallery_with_space':
				$classes[] = 'edgtf-ptf-gallery-with-space';
				break;
			case 'masonry':
				$classes[] = 'edgtf-ptf-masonry';
				break;
			case 'masonry_with_space':
				$classes[] = 'edgtf-ptf-masonry-with-space';
				break;
		endswitch;

		if (empty($params['portfolio_slider'])) { // portfolio slider mustn't have this classes

			switch ($columns):
				case 'one':
					$classes[] = 'edgtf-ptf-one-column';
					break;
				case 'two':
					$classes[] = 'edgtf-ptf-two-columns';
					break;
				case 'three':
					$classes[] = 'edgtf-ptf-three-columns';
					break;
				case 'four':
					$classes[] = 'edgtf-ptf-four-columns';
					break;
				case 'five':
					$classes[] = 'edgtf-ptf-five-columns';
					break;
				case 'six':
					$classes[] = 'edgtf-ptf-six-columns';
					break;
			endswitch;

			if ($params['show_load_more'] == 'yes') {
				$classes[] = 'edgtf-ptf-load-more';
			}
		}

		if ($params['filter'] == 'yes') {
			$classes[] = 'edgtf-ptf-has-filter';
			if ($params['type'] == 'masonry' || $type == 'masonry_with_space') {
				if ($params['filter'] == 'yes') {
					$classes[] = 'edgtf-ptf-masonry-filter';
				}
			}
		}

		if (!empty($params['portfolio_slider']) && $params['portfolio_slider'] == 'yes') {
			$classes[] = 'edgtf-portfolio-slider-holder';
		}

		return implode(' ', $classes);

	}

	/**
	 * Generates portfolio image size
	 *
	 * @param $params
	 *
	 * @return string
	 */
	public function getImageSize($params)
	{

		$thumb_size = 'full';
		$type = $params['type'];

		if ($type == 'standard' || $type == 'gallery' || $type == 'gallery_with_space') {
			if (!empty($params['image_size'])) {
				$image_size = $params['image_size'];

				switch ($image_size) {
					case 'landscape':
						$thumb_size = 'portfolio-landscape';
						break;
					case 'portrait':
						$thumb_size = 'portfolio-portrait';
						break;
					case 'square':
						$thumb_size = 'portfolio-square';
						break;
					case 'full':
						$thumb_size = 'full';
						break;
				}
			}
		} elseif ($type == 'masonry' || $type == 'masonry_with_space') {

			$id = $params['current_id'];
			$masonry_size = get_post_meta($id, 'edgtf_portfolio_masonry_dimenisions', true);

			switch ($masonry_size):
				case 'default' :
					$thumb_size = 'portfolio-square';
					break;
				case 'large_width' :
					$thumb_size = 'portfolio-large-width';
					break;
				case 'large_height' :
					$thumb_size = 'portfolio-large-height';
					break;
				case 'large_width_height' :
					$thumb_size = 'portfolio-large-width-height';
					break;
			endswitch;
		}


		return $thumb_size;
	}

	/**
	 * Generates portfolio item categories ids.This function is used for filtering
	 *
	 * @param $params
	 *
	 * @return array
	 */
	public function getItemCategories($params)
	{
		$id = $params['current_id'];
		$category_return_array = array();

		$categories = wp_get_post_terms($id, 'portfolio-category');

		foreach ($categories as $cat) {
			$category_return_array[] = 'portfolio_category_' . $cat->term_id;
		}
		return implode(' ', $category_return_array);
	}

	/**
	 * Generates portfolio item categories html based on id
	 *
	 * @param $params
	 *
	 * @return html
	 */
	public function getItemCategoriesHtml($params)
	{
		$id = $params['current_id'];

		$categories = wp_get_post_terms($id, 'portfolio-category');
		$category_html = '<div class="edgtf-ptf-category-holder">';
		$k = 1;
		foreach ($categories as $cat) {
			$category_html .= '<span>' . $cat->name . '</span>';
			if (count($categories) != $k) {
				$category_html .= ' / ';
			}
			$k++;
		}
		$category_html .= '</div>';
		return $category_html;
	}

	/**
	 * Generates masonry size class for each article( based on id)
	 *
	 * @param $params
	 *
	 * @return string
	 */
	public function getMasonrySize($params)
	{
		$masonry_size_class = '';
		if ($params['type'] == 'masonry' || $params['type'] == 'masonry_with_space') {

			$id = $params['current_id'];
			$masonry_size = get_post_meta($id, 'edgtf_portfolio_masonry_dimenisions', true);
			switch ($masonry_size):
				case 'default' :
					$masonry_size_class = 'edgtf-default-masonry-item';
					break;
				case 'large_width' :
					$masonry_size_class = 'edgtf-large-width-masonry-item';
					break;
				case 'large_height' :
					$masonry_size_class = 'edgtf-large-height-masonry-item';
					break;
				case 'large_width_height' :
					$masonry_size_class = 'edgtf-large-width-height-masonry-item';
					break;
			endswitch;
		}

		return $masonry_size_class;
	}

	/**
	 * Generates filter categories array
	 *
	 * @param $params
	 *
	 *
	 *
	 *
	 * * @return array
	 */
	public function getFilterCategories($params)
	{

		$cat_id = 0;
		$top_category = '';

		if (!empty($params['category'])) {

			$top_category = get_term_by('slug', $params['category'], 'portfolio-category');
			if (isset($top_category->term_id)) {
				$cat_id = $top_category->term_id;
			}

		}

		$args = array(
			'child_of' => $cat_id,
			'order_by' => $params['filter_order_by']
		);

		$filter_categories = get_terms('portfolio-category', $args);

		return $filter_categories;

	}

	/**
	 * Generates datta attributes array
	 *
	 * @param $params
	 *
	 * @return array
	 */
	public function getDataAtts($params)
	{

		$data_attr = array();
		$data_return_string = '';

		if (get_query_var('paged')) {
			$paged = get_query_var('paged');
		} elseif (get_query_var('page')) {
			$paged = get_query_var('page');
		} else {
			$paged = 1;
		}

		if (!empty($paged)) {
			$data_attr['data-next-page'] = $paged + 1;
		}
		if (!empty($params['type'])) {
			$data_attr['data-type'] = $params['type'];
		}
		if (!empty($params['columns'])) {
			$data_attr['data-columns'] = $params['columns'];
		}
		if (!empty($params['grid_size'])) {
			$data_attr['data-grid-size'] = $params['grid_size'];
		}
		if (!empty($params['order_by'])) {
			$data_attr['data-order-by'] = $params['order_by'];
		}
		if (!empty($params['order'])) {
			$data_attr['data-order'] = $params['order'];
		}
		if (!empty($params['number'])) {
			$data_attr['data-number'] = $params['number'];
		}
		if (!empty($params['image_size'])) {
			$data_attr['data-image-size'] = $params['image_size'];
		}
		if (!empty($params['filter'])) {
			$data_attr['data-filter'] = $params['filter'];
		}
		if (!empty($params['filter_order_by'])) {
			$data_attr['data-filter-order-by'] = $params['filter_order_by'];
		}
		if (!empty($params['category'])) {
			$data_attr['data-filter-order-by'] = $params['category'];
		}
		if (!empty($params['selected_projectes'])) {
			$data_attr['data-selected-projects'] = $params['selected_projectes'];
		}
		if (!empty($params['show_load_more'])) {
			$data_attr['data-show-load-more'] = $params['show_load_more'];
		}
		if (!empty($params['title_tag'])) {
			$data_attr['data-title-tag'] = $params['title_tag'];
		}
		if (!empty($params['portfolio_slider']) && $params['portfolio_slider'] == 'yes') {
			$data_attr['data-items'] = $params['portfolios_shown'];
		}

		foreach ($data_attr as $key => $value) {
			if ($key !== '') {
				$data_return_string .= $key . '= ' . esc_attr($value) . ' ';
			}
		}
		return $data_return_string;
	}

	/**
	 * Generates item link
	 *
	 * @param $params
	 *
	 * @return array
	 */
	public function getItemLink($params)
	{
		$id = $params['current_id'];
		$portfolio_link = get_permalink($id);
		if (get_post_meta($id, 'edgtf_portfolio_external_link',true) !== ''){
			$portfolio_link = get_post_meta($id, 'edgtf_portfolio_external_link',true);
		}

		return $portfolio_link;

	}

}